<?php

$lang['edit_options'] = 'Edit Options';
$lang['edit_options_successful'] = 'Options successfully edited.';

$lang['web_name'] = 'Website Name';
$lang['top_name'] = 'Top Name';
$lang['bottom_name'] = 'Bottom Name';
$lang['left_logo'] = 'Left Logo Filename';
$lang['right_logo1'] = 'Right Logo 1 Filename';
$lang['right_logo2'] = 'Right Logo 2 Filename';
$lang['items_per_page'] = 'Items per Page';


/* End of file option_lang.php */
/* Location: ./application/language/english/option_lang.php */
