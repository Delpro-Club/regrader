<?php

$lang['public_scoreboard'] = 'Public Scoreboard';
$lang['public_raw_scoreboard'] = 'Public Raw Scoreboard';
$lang['no_contest'] = 'No contests.';
$lang['as_admin'] = 'As Administrator';
$lang['as_contestant'] = 'As Contestant';
$lang['score'] = 'Score';
$lang['frozen_since'] = 'Frozen since';

/* End of file scoreboard_lang.php */
/* Location: ./application/language/english/scoreboard_lang.php */
