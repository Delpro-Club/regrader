<?php

$lang['active_contests'] = 'Active Contests';
$lang['active_users'] = 'Active Users';
$lang['active_graders'] = 'Active Graders';
$lang['choose_contest'] = 'Choose Contest';
$lang['please_choose_contest'] = 'Please choose one of the available contests.';
$lang['no_contest'] = 'No contests.';
$lang['compete'] = 'Compete';
$lang['running'] = 'running';

/* End of file dashboard_lang.php */
/* Location: ./application/language/english/dashboard_lang.php */
