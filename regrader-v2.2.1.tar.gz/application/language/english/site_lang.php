<?php

$lang['guest'] = 'Guest';
$lang['please_login'] = 'Please log in.';
$lang['username'] = 'Username';
$lang['password'] = 'Password';
$lang['login'] = 'Log in';
$lang['wrong_credentials'] = 'Wrong username or password.';

/* End of file site_lang.php */
/* Location: ./application/language/english/site_lang.php */
