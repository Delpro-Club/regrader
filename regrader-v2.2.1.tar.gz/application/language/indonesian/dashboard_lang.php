<?php

$lang['active_contests'] = 'Kontes Sedang Aktif';
$lang['active_users'] = 'Anggota Sedang Aktif';
$lang['active_graders'] = 'Penguji Sedang Aktif';
$lang['choose_contest'] = 'Pilih Kontes';
$lang['please_choose_contest'] = 'Silakan pilih salah satu kontes yang tersedia.';
$lang['no_contest'] = 'Belum ada kontes.';
$lang['compete'] = 'Tanding';
$lang['running'] = 'berjalan';

/* End of file dashboard_lang.php */
/* Location: ./application/language/indonesian/dashboard_lang.php */
