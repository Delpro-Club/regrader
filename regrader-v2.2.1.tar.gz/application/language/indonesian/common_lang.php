<?php

$lang['dashboard'] = 'Beranda';
$lang['submission'] = 'Pengumpulan';
$lang['submissions'] = 'Pengumpulan';
$lang['clarification'] = 'Klarifikasi';
$lang['clarifications'] = 'Klarifikasi';
$lang['new'] = 'baru';
$lang['scoreboard'] = 'Peringkat';
$lang['manage'] = 'Atur';
$lang['edit'] = 'Sunting';
$lang['delete'] = 'Hapus';
$lang['add'] = 'Tambah';
$lang['save'] = 'Simpan';
$lang['cancel'] = 'Batal';
$lang['back'] = 'Kembali';
$lang['contest'] = 'Kontes';
$lang['contests'] = 'Kontes';
$lang['problem'] = 'Soal';
$lang['problems'] = 'Soal';
$lang['language'] = 'Bahasa';
$lang['languages'] = 'Bahasa';
$lang['category'] = 'Kategori';
$lang['categories'] = 'Kategori';
$lang['user'] = 'Anggota';
$lang['users'] = 'Anggota';
$lang['grader'] = 'Penguji';
$lang['graders'] = 'Penguji';
$lang['file'] = 'Berkas';
$lang['files'] = 'Berkas';
$lang['option'] = 'Pengaturan';
$lang['options'] = 'Pengaturan';
$lang['logout'] = 'Keluar';
$lang['name'] = 'Nama';
$lang['time'] = 'Waktu';
$lang['general_info'] = 'Informasi Umum';
$lang['info'] = 'Info';
$lang['value'] = 'Nilai';
$lang['filter'] = 'Saring';
$lang['view'] = 'Lihat';
$lang['status'] = 'Status';
$lang['remaining'] = 'tersisa';

/* End of file common_lang.php */
/* Location: ./application/language/indonesian/common_lang.php */
