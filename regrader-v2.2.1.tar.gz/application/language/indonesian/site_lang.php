<?php

$lang['guest'] = 'Tamu';
$lang['please_login'] = 'Silakan masuk.';
$lang['username'] = 'Username';
$lang['password'] = 'Password';
$lang['login'] = 'Masuk';
$lang['wrong_credentials'] = 'Username atau password salah.';

/* End of file site_lang.php */
/* Location: ./application/language/indonesian/site_lang.php */
