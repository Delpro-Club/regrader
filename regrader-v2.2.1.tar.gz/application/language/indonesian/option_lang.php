<?php

$lang['edit_options'] = 'Sunting Pengaturan';
$lang['edit_options_successful'] = 'Pengaturan berhasil disunting.';

$lang['web_name'] = 'Nama Situs';
$lang['top_name'] = 'Nama Atas';
$lang['bottom_name'] = 'Nama Bawah';
$lang['left_logo'] = 'Nama Berkas Logo Kiri';
$lang['right_logo1'] = 'Nama Berkas Logo Kanan 1';
$lang['right_logo2'] = 'Nama Berkas Logo Kanan 2';
$lang['items_per_page'] = 'Item per Halaman';


/* End of file option_lang.php */
/* Location: ./application/language/indonesian/option_lang.php */
