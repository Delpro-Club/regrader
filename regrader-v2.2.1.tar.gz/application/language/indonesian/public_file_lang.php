<?php

$lang['file_list'] = 'Daftar Berkas';
$lang['add_new_file'] = 'Tambah Berkas Baru';
$lang['showing_files'] = 'Menampilkan berkas ke-%d sampai dengan ke-%d dari total %d.';
$lang['edit_file'] = 'Sunting Berkas';
$lang['add_file'] = 'Tambah Berkas';
$lang['add_file_successful'] = 'Berkas berhasil ditambahkan.';
$lang['delete_file_successful'] = 'Berkas berhasil dihapus.';
$lang['no_file'] = 'Belum ada berkas.';
$lang['new_file'] = 'Berkas Baru';
$lang['confirm_delete_file'] = 'Anda yakin ingin menghapus berkas %s?';
$lang['file_required'] = "'Berkas' diperlukan.";

/* End of file file_lang.php */
/* Location: ./application/language/indonesian/file_lang.php */
