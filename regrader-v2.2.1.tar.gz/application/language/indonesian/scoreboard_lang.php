<?php

$lang['public_scoreboard'] = 'Tautan Umum';
$lang['public_raw_scoreboard'] = 'Tautan Umum Mentah';
$lang['no_contest'] = 'Belum ada kontes.';
$lang['as_admin'] = 'Sebagai Administrator';
$lang['as_contestant'] = 'Sebagai Peserta';
$lang['score'] = 'Nilai';
$lang['frozen_since'] = 'Dibekukan sejak';

/* End of file scoreboard_lang.php */
/* Location: ./application/language/indonesian/scoreboard_lang.php */
